package com.example.proyectofinalsje;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Memoria extends AppCompatActivity {
    BDJuegos bdJuegos;
    String nombreJugador;
    String tiempoFinal;

    boolean primeraFicha = true;
    boolean inicio = true;
    int fichaTemporal;
    int fichasResueltas = 0;
    List<Integer> listaImagenes;
    TextView textoInformacion;
    Integer botonesMemoria[];
    Integer imagenesMemoria[];
    List<Integer> imagenesUsadas = new ArrayList<>();
    int tableroMemoria[] = new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    TextView temporizador, textoCuentaAtras, textoTiempo;
    long startTime = 0;

    Handler timerHandler = new Handler();
    Runnable timerRunnable = new Runnable() {

        @Override
        public void run() {
            long millis = System.currentTimeMillis() - startTime;
            int seconds = (int) (millis / 1000);
            int minutes = seconds / 60;
            seconds = seconds % 60;

            temporizador.setText(String.format("%d:%02d", minutes, seconds));

            timerHandler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memoria);

        ConstraintLayout constraintLayout = findViewById(R.id.memoriaLayout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(3000);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        bdJuegos = BDJuegos.getDataBase(this);

        temporizador = (TextView) findViewById(R.id.temporizador1);
        temporizador.setVisibility(View.GONE);
        startTime = System.currentTimeMillis();
        timerHandler.postDelayed(timerRunnable, 0);

        nombreJugador = getIntent().getExtras().getString("nombreJugador");

        textoInformacion = (TextView) findViewById(R.id.textoInformacion);
        textoInformacion.setText("¡Memoriza las imágenes!");
        textoCuentaAtras = (TextView) findViewById(R.id.textoCuentaAtras);
        textoTiempo = (TextView) findViewById(R.id.tiempo1);
        textoTiempo.setVisibility(View.GONE);

        botonesMemoria = new Integer[]{ R.id.boton00, R.id.boton01, R.id.boton02, R.id.boton03, R.id.boton04, R.id.boton05, R.id.boton06, R.id.boton07, R.id.boton08, R.id.boton09, R.id.boton10, R.id.boton11};
        imagenesMemoria = new Integer[]{ R.id.imagen00, R.id.imagen01, R.id.imagen02, R.id.imagen03, R.id.imagen04, R.id.imagen05, R.id.imagen06, R.id.imagen07, R.id.imagen08, R.id.imagen09, R.id.imagen09, R.id.imagen10};
        listaImagenes = new ArrayList<>();
        listaImagenes.add(R.drawable.cruz);
        listaImagenes.add(R.drawable.circulo);
        listaImagenes.add(R.drawable.spriteflappybird);
        listaImagenes.add(R.drawable.user);
        listaImagenes.add(R.drawable.pipe_up);
        listaImagenes.add(R.drawable.memoria);
        desordenaFichas();
        cuentaAtras();


    }

    public void compruebaFicha(View vista) {
        if (!inicio) {
            int numBoton = Arrays.asList(botonesMemoria).indexOf(vista.getId());
            if (primeraFicha) {
                vista.setBackgroundResource(listaImagenes.get(tableroMemoria[numBoton]));
                primeraFicha = false;
                fichaTemporal = numBoton;
                System.out.println("primera ficha");
                System.out.println(Arrays.toString(tableroMemoria));
            } else {
                if (tableroMemoria[fichaTemporal] != tableroMemoria[numBoton]) {
                    ImageButton b = findViewById(botonesMemoria[fichaTemporal]);
                    b.setBackgroundColor(Color.GRAY);
                    vista.setBackgroundColor(Color.GRAY);
                    System.out.println("fallo");
                    System.out.println(Arrays.toString(tableroMemoria));
                } else {
                    ImageButton b = findViewById(botonesMemoria[fichaTemporal]);
                    b.setVisibility(View.GONE);
                    vista.setVisibility(View.GONE);
                    ImageView imageView = findViewById(imagenesMemoria[fichaTemporal]);
                    imageView.setBackgroundResource(listaImagenes.get(tableroMemoria[fichaTemporal]));
                    imageView.setVisibility(View.VISIBLE);
                    imageView = findViewById(imagenesMemoria[numBoton]);
                    imageView.setBackgroundResource(listaImagenes.get(tableroMemoria[numBoton]));
                    imageView.setVisibility(View.VISIBLE);
                    fichasResueltas += 2;
                    System.out.println("acierto");
                    System.out.println(Arrays.toString(tableroMemoria));
                }
                primeraFicha = true;
                fichaTemporal = 0;
            }
            compruebaVictoria();
        }
    }

    public void compruebaVictoria() {
        if (fichasResueltas == 12) {
            textoInformacion.setText("¡Lo lograste!");
            timerHandler.removeCallbacks(timerRunnable);

            String temporal = temporizador.getText() + "";
            int puntuacion = 0;
            puntuacion = Integer.parseInt(temporal.split(":")[0]) * 60 + Integer.parseInt(temporal.split(":")[1]);
            if(tiempoFinal != null) {
                if (Integer.parseInt(tiempoFinal) > puntuacion) {
                    tiempoFinal = puntuacion + "";
                }
            } else {
                tiempoFinal = puntuacion + "";
            }
        }
    }

    public void resetJuego(View vista) {
        if (fichasResueltas == 12) {
            inicio = true;
            fichasResueltas = 0;
            tableroMemoria = new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
            desordenaFichas();
            cuentaAtras();
            textoInformacion.setText("Memoriza las fichas");
        }
    }

    public void cuentaAtras() {
        textoCuentaAtras.setVisibility(View.VISIBLE);
        textoTiempo.setVisibility(View.INVISIBLE);
        temporizador.setVisibility(View.INVISIBLE);

        new CountDownTimer(3000, 1000) {

            public void onTick(long millisUntilFinished) {
                textoCuentaAtras.setText("Empieza en " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                textoCuentaAtras.setVisibility(View.INVISIBLE);
                textoTiempo.setVisibility(View.VISIBLE);
                temporizador.setVisibility(View.VISIBLE);
                ocultaBotones();
                inicio = false;
                System.out.println(Arrays.toString(tableroMemoria));
            }

        }.start();
    }

    public void desordenaFichas() {
        imagenesUsadas.add(0);
        imagenesUsadas.add(1);
        imagenesUsadas.add(2);
        imagenesUsadas.add(3);
        imagenesUsadas.add(4);
        imagenesUsadas.add(5);
        for (int i = 0; i < imagenesMemoria.length; i++){
            ImageView b = findViewById(imagenesMemoria[i]);
            b.setVisibility(View.GONE);
        }
        for (int i = 0; i < botonesMemoria.length; i++){
            ImageButton b = findViewById(botonesMemoria[i]);
            b.setVisibility(View.VISIBLE);
            b.setBackgroundColor(Color.GRAY);
        }
        Random azar = new Random();
        for (int i = 0; i < botonesMemoria.length; i++) {
            ImageButton b = findViewById(botonesMemoria[i]);
            if (tableroMemoria[i] == -1) {
                int numTemporal = azar.nextInt(imagenesUsadas.size());
                int imagen = imagenesUsadas.get(numTemporal);
                b.setBackgroundResource(listaImagenes.get(imagen));
                tableroMemoria[i] = imagen;
                int otroBoton = azar.nextInt(botonesMemoria.length);
                while(tableroMemoria[otroBoton] != -1){
                    otroBoton = azar.nextInt(botonesMemoria.length);
                }
                b = findViewById(botonesMemoria[otroBoton]);
                b.setBackgroundResource(listaImagenes.get(imagen));
                tableroMemoria[otroBoton] = imagen;
                imagenesUsadas.remove(numTemporal);
            }
        }
    }

    public void ocultaBotones(){
        startTime = System.currentTimeMillis();
        timerHandler.postDelayed(timerRunnable, 0);
        for (int i = 0; i < botonesMemoria.length; i++){
            ImageButton b = findViewById(botonesMemoria[i]);
            b.setBackgroundColor(Color.GRAY);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        System.out.println(nombreJugador);
        if (tiempoFinal != null) {
            Jugador jugador = (Jugador) bdJuegos.obtenerDAOJuegos().SacarJugadorPorNombre(nombreJugador);
            if (jugador != null) {
                Partida partida = (Partida) bdJuegos.obtenerDAOJuegos().SacarPartidaPorIdDeJugador(jugador.idJugador, 3);
                if (partida != null) {
                    if (Integer.parseInt(partida.puntuacion) > Integer.parseInt(tiempoFinal)) {
                        bdJuegos.obtenerDAOJuegos().ActualizarPartida(tiempoFinal, jugador.idJugador, 3);
                        System.out.println("edito");
                    }
                } else {
                    partida = new Partida(jugador.idJugador, 3, tiempoFinal);
                    bdJuegos.obtenerDAOJuegos().InsertarPartida(partida);
                    System.out.println("gurado en jugador");
                }
            } else {
                jugador = new Jugador(nombreJugador);
                bdJuegos.obtenerDAOJuegos().InsertarJugador(jugador);
                jugador = (Jugador) bdJuegos.obtenerDAOJuegos().SacarJugadorPorNombre(nombreJugador);
                Partida partida = new Partida(jugador.idJugador, 3, tiempoFinal);
                bdJuegos.obtenerDAOJuegos().InsertarPartida(partida);
                System.out.println("guardo nueva");
            }

        }
    }
}