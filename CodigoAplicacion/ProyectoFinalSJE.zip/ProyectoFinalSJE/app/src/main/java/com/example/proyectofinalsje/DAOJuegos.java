package com.example.proyectofinalsje;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface DAOJuegos
{
    @Insert
    void InsertarJugador(Jugador... jugador);

    @Delete
    void BorrarJugador(Jugador... jugador);

    @Query("select * from Jugador")
    List<Jugador> TodosLosJugadores ();

    @Query("select * from Jugador where idJugador = :idJugador")
    Jugador SacarJugador (int idJugador);

    @Query("select * from Jugador where nombreJugador = :nombreJugador")
    Jugador SacarJugadorPorNombre (String nombreJugador);

    @Insert
    void InsertarJuego(Juego... juego);

    @Delete
    void BorrarJuego(Juego... juego);

    @Query("select * from Juego")
    List<Juego> TodosLosJuegos ();

    @Query("select * from Juego where idJuego = :idJuego")
    Juego SacarJuego (int idJuego);

    @Insert
    void InsertarPartida(Partida... partida);

    @Delete
    void BorrarPartida(Partida... partida);

    @Query("select * from Partida")
    List<Partida> TodasLasPartidas ();

    @Query("select * from Partida where idPartida = :idPartida")
    Partida SacarPartida (int idPartida);

    @Query("select * from Partida where idJugador = :idJugador and idJuego = :idJuego")
    Partida SacarPartidaPorIdDeJugador (int idJugador, int idJuego);

    @Query("select * from Partida where idJuego = :idJuego order by cast (puntuacion as integer) desc limit 1")
    Partida SacarPartidaDeJuegoPorPuntuacion (int idJuego);

    @Query("select * from Partida where idJuego = :idJuego order by cast (puntuacion as integer) asc limit 1")
    Partida SacarPartidaDeJuegoPorSegundos (int idJuego);

    @Query("update Partida set puntuacion = :puntuacion where idJugador = :idJugador and idJuego = :idJuego")
    int ActualizarPartida (String puntuacion, int idJugador, int idJuego);

}
