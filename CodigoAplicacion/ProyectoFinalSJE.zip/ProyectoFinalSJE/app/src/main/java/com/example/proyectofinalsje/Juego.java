package com.example.proyectofinalsje;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Juego
{
    @PrimaryKey(autoGenerate = true)
    int idJuego;
    String nombreJuego;


    public Juego(String nombreJuego)
    {
        this.nombreJuego = nombreJuego;
    }

    public int getIdJuego() {
        return idJuego;
    }

    public void setIdJuego(int idJuego) {
        this.idJuego = idJuego;
    }

    public String getNombreJuego() {
        return nombreJuego;
    }

    public void setNombreJuego(String nombreJuego) {
        this.nombreJuego = nombreJuego;
    }

}
