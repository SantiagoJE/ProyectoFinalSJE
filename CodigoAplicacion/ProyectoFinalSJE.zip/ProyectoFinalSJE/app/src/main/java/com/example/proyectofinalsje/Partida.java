package com.example.proyectofinalsje;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Partida
{
    @PrimaryKey(autoGenerate = true)
    int idPartida;
    int idJugador;
    int idJuego;
    String puntuacion;

    public Partida(int idJugador, int idJuego, String puntuacion)
    {
        this.idJugador = idJugador;
        this.idJuego = idJuego;
        this.puntuacion = puntuacion;
    }

    public int getIdPartida() {
        return idPartida;
    }

    public void setIdPartida(int idPartida) {
        this.idPartida = idPartida;
    }

    public int getIdJugador() {
        return idJugador;
    }

    public void setIdJugador(int idJugador) {
        this.idJugador = idJugador;
    }

    public int getIdJuego() {
        return idJuego;
    }

    public void setIdJuego(int idJuego) {
        this.idJuego = idJuego;
    }

    public String getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(String puntuacion) {
        this.puntuacion = puntuacion;
    }

}
