package com.example.proyectofinalsje;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Jugador
{
    @PrimaryKey(autoGenerate = true)
    int idJugador;
    String nombreJugador;


    public Jugador(String nombreJugador)
    {
        this.nombreJugador = nombreJugador;
    }

    public int getIdJugador() {
        return idJugador;
    }

    public void setIdJugador(int idJugador) {
        this.idJugador = idJugador;
    }

    public String getNombreJugador() {
        return nombreJugador;
    }

    public void setNombreJugador(String nombreJugador) {
        this.nombreJugador = nombreJugador;
    }

}
