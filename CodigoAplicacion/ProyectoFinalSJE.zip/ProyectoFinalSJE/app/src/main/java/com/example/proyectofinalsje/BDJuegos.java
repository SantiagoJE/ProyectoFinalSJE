package com.example.proyectofinalsje;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

//clase abstracta que define las características de la base de datos Room
@Database(entities = {Jugador.class, Juego.class, Partida.class}, version = 5)
public abstract class BDJuegos extends RoomDatabase
{
    public abstract DAOJuegos obtenerDAOJuegos();

    public static BDJuegos getDataBase(Context contexto)
    {
        BDJuegos bd = Room.databaseBuilder(contexto,
                BDJuegos.class, "bbddJuegos").allowMainThreadQueries().build();
        return bd;
    }
}
