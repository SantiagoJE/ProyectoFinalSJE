package com.example.proyectofinalsje;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class TresEnRaya extends AppCompatActivity {
    BDJuegos bdJuegos;
    String nombreJugador;
    String tiempoFinal;

    TextView temporizador;
    long startTime = 0;

    Handler timerHandler = new Handler();
    Runnable timerRunnable = new Runnable() {

        @Override
        public void run() {
            long millis = System.currentTimeMillis() - startTime;
            int seconds = (int) (millis / 1000);
            int minutes = seconds / 60;
            seconds = seconds % 60;

            temporizador.setText(String.format("%d:%02d", minutes, seconds));

            timerHandler.postDelayed(this, 500);
        }
    };

    TextView textoFinal;
    Integer botones[];
    int tablero[] = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
    int estadoPartida = 0;
    int fichasPuestas = 0;
    int turno = 1;
    int[] posGanadora = new int[]{-1, -1, -1};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tres_en_raya);

        ConstraintLayout constraintLayout = findViewById(R.id.tresenrayaLayout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.start();

        bdJuegos = BDJuegos.getDataBase(this);

        temporizador = (TextView) findViewById(R.id.temporizador);
        startTime = System.currentTimeMillis();
        timerHandler.postDelayed(timerRunnable, 0);

        nombreJugador = getIntent().getExtras().getString("nombreJugador");

        textoFinal = (TextView) findViewById(R.id.textoFinal);
        textoFinal.setVisibility(View.INVISIBLE);
        botones = new Integer[]{ R.id.boton1, R.id.boton2, R.id.boton3, R.id.boton4, R.id.boton5, R.id.boton6, R.id.boton7, R.id.boton8, R.id.boton9};

        for (int i = 0; i < botones.length; i++){
            ImageButton b = findViewById(botones[i]);
            b.setBackgroundColor(Color.GRAY);
        }

    }

    public void ponerFicha(View vista){
        if (estadoPartida == 0) {
            turno = 1;
            int numBoton = Arrays.asList(botones).indexOf(vista.getId());
            if (tablero[numBoton] == 0) {
                vista.setBackgroundResource(R.drawable.circulo);
                tablero[numBoton] = 1;
                fichasPuestas++;
                estadoPartida = comprobarEstado();
                terminarPartida();
                if (estadoPartida == 0) {
                    turno = -1;
                    ia();
                    estadoPartida = comprobarEstado();
                    terminarPartida();
                }
            }
        } else {
            startTime = System.currentTimeMillis();
            timerHandler.postDelayed(timerRunnable, 0);
            for (int i = 0; i < botones.length; i++){
                ImageButton b = findViewById(botones[i]);
                b.setBackgroundColor(Color.GRAY);
            }
            tablero = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
            posGanadora = new int[]{-1, -1, -1};
            estadoPartida = 0;
            fichasPuestas = 0;
            textoFinal.setVisibility(View.INVISIBLE);
        }
    }

    public void ia(){
        Random random = new Random();
        int pos = random.nextInt(tablero.length);
        while (tablero[pos] != 0) {
            pos = random.nextInt(tablero.length);
        }
        ImageButton boton = (ImageButton) findViewById(botones[pos]);
        boton.setBackgroundResource(R.drawable.cruz);
        tablero[pos] = -1;
        fichasPuestas++;
    }

    public int comprobarEstado() {
        int estado = 0;
        if (Math.abs(tablero[0] + tablero[1] + tablero[2]) == 3){
            posGanadora = new int[]{0,1,2};
            estado = 1 * turno;
        } else if (Math.abs(tablero[3] + tablero[4] + tablero[5]) == 3){
            posGanadora = new int[]{3,4,5};
            estado = 1 * turno;
        } else if (Math.abs(tablero[6] + tablero[7] + tablero[8]) == 3){
            posGanadora = new int[]{6,7,8};
            estado = 1 * turno;
        } else if (Math.abs(tablero[0] + tablero[3] + tablero[6]) == 3){
            posGanadora = new int[]{0,3,6};
            estado = 1 * turno;
        } else if (Math.abs(tablero[1] + tablero[4] + tablero[7]) == 3){
            posGanadora = new int[]{1,4,7};
            estado = 1 * turno;
        } else if (Math.abs(tablero[2] + tablero[5] + tablero[8]) == 3){
            posGanadora = new int[]{2,5,8};
            estado = 1 * turno;
        } else if (Math.abs(tablero[0] + tablero[4] + tablero[8]) == 3){
            posGanadora = new int[]{0,4,8};
            estado = 1 * turno;
        } else if (Math.abs(tablero[2] + tablero[4] + tablero[6]) == 3){
            posGanadora = new int[]{2,4,6};
            estado = 1 * turno;
        } else if (fichasPuestas == 9) {
            estado = 2;
        }
        return estado;

    }

    public void terminarPartida() {
        if (estadoPartida == 1){
            textoFinal.setVisibility(View.VISIBLE);
            textoFinal.setText("¡Has ganado!");
            textoFinal.setTextColor(Color.GREEN);
            for (int i = 0; i < posGanadora.length; i++){
                ImageButton b = findViewById(botones[posGanadora[i]]);
                b.setBackgroundColor(Color.GREEN);
            }
            timerHandler.removeCallbacks(timerRunnable);

            String temporal = temporizador.getText() + "";
            int puntuacion = 0;
            puntuacion = Integer.parseInt(temporal.split(":")[0]) * 60 + Integer.parseInt(temporal.split(":")[1]);
            if(tiempoFinal != null) {
                if (Integer.parseInt(tiempoFinal) > puntuacion) {
                    tiempoFinal = puntuacion + "";
                }
            } else {
                tiempoFinal = puntuacion + "";
            }

        } else if (estadoPartida == -1) {
            textoFinal.setVisibility(View.VISIBLE);
            textoFinal.setText("¡Has perdido!");
            textoFinal.setTextColor(Color.RED);
            for (int i = 0; i < posGanadora.length; i++){
                ImageButton b = findViewById(botones[posGanadora[i]]);
                b.setBackgroundColor(Color.RED);
            }
            timerHandler.removeCallbacks(timerRunnable);

        } else if (estadoPartida == 2) {
            textoFinal.setVisibility(View.VISIBLE);
            textoFinal.setText("¡Has empatado!");
            timerHandler.removeCallbacks(timerRunnable);
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        System.out.println(nombreJugador);
        if (tiempoFinal != null) {
            Jugador jugador = (Jugador) bdJuegos.obtenerDAOJuegos().SacarJugadorPorNombre(nombreJugador);
            if (jugador != null) {
                Partida partida = (Partida) bdJuegos.obtenerDAOJuegos().SacarPartidaPorIdDeJugador(jugador.idJugador, 2);
                if (partida != null) {
                    if (Integer.parseInt(partida.puntuacion) > Integer.parseInt(tiempoFinal)) {
                        bdJuegos.obtenerDAOJuegos().ActualizarPartida(tiempoFinal, jugador.idJugador, 2);
                        System.out.println("edito");
                    }
                } else {
                    partida = new Partida(jugador.idJugador, 2, tiempoFinal);
                    bdJuegos.obtenerDAOJuegos().InsertarPartida(partida);
                    System.out.println("gurado en jugador");
                }
            } else {
                jugador = new Jugador(nombreJugador);
                bdJuegos.obtenerDAOJuegos().InsertarJugador(jugador);
                jugador = (Jugador) bdJuegos.obtenerDAOJuegos().SacarJugadorPorNombre(nombreJugador);
                Partida partida = new Partida(jugador.idJugador, 2, tiempoFinal);
                bdJuegos.obtenerDAOJuegos().InsertarPartida(partida);
                System.out.println("guardo nueva");
            }

        }
    }

}