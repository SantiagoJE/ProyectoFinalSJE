package com.example.proyectofinalsje;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    BDJuegos bdJuegos;
    Intent intencion;
    private String nombreJugador;
    TextView titulo1, titulo2, jugador1, jugador2, puntuacion1, puntuacion2, titulo3, jugador3, puntuacion3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConstraintLayout constraintLayout = findViewById(R.id.mainLayout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.start();

        bdJuegos = BDJuegos.getDataBase(this);
        ArrayList<Jugador> jugadores = (ArrayList<Jugador>) bdJuegos.obtenerDAOJuegos().TodosLosJugadores();
        if (jugadores.size() == 0){
            rellenaBaseDatos();
        }
        titulo1 = (TextView) findViewById(R.id.titulo1);
        titulo2 = (TextView) findViewById(R.id.titulo2);
        jugador1 = (TextView) findViewById(R.id.jugador1);
        jugador2 = (TextView) findViewById(R.id.jugador2);
        puntuacion1 = (TextView) findViewById(R.id.puntuacion1);
        puntuacion2 = (TextView) findViewById(R.id.puntuacion2);
        titulo3 = (TextView) findViewById(R.id.titulo3);
        jugador3 = (TextView) findViewById(R.id.jugador3);
        puntuacion3 = (TextView) findViewById(R.id.puntuacion3);
        actualizarJuegos();

        ImageButton botonJugador = (ImageButton) findViewById(R.id.botonJugador);
        botonJugador.setImageResource(R.drawable.user);
        botonJugador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                identificarJugador();
            }
        });

        ImageView flappyBird = (ImageView) findViewById(R.id.flappyBird);
        flappyBird.setImageResource(R.drawable.spriteflappybird);
 /*       flappyBird.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                intencion = new Intent(v.getContext(), Puntuaciones.class);
                intencion.putExtra("juego", "flappybird.png");
                startActivity(intencion);
                return true;
            }
        }); */
        flappyBird.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nombreJugador == null){
                    identificarJugador();
                } else {
                    intencion = new Intent(v.getContext(), FlappyBird.class);
                    intencion.putExtra("nombreJugador", nombreJugador);
                    startActivity(intencion);
                }
            }
        });

        ImageView tresEnRaya = (ImageView) findViewById(R.id.tresEnRaya);
        tresEnRaya.setImageResource(R.drawable.tresenraya);
 /*       flappyBird.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                intencion = new Intent(v.getContext(), Puntuaciones.class);
                intencion.putExtra("juego", "flappybird.png");
                startActivity(intencion);
                return true;
            }
        }); */
        tresEnRaya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nombreJugador == null) {
                    identificarJugador();
                } else {
                    intencion = new Intent(v.getContext(), TresEnRaya.class);
                    intencion.putExtra("nombreJugador", nombreJugador);
                    startActivity(intencion);
                }
            }
        });

        ImageView memoria = (ImageView) findViewById(R.id.memoria);
        memoria.setImageResource(R.drawable.memoria);
 /*       flappyBird.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                intencion = new Intent(v.getContext(), Puntuaciones.class);
                intencion.putExtra("juego", "flappybird.png");
                startActivity(intencion);
                return true;
            }
        }); */
        memoria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nombreJugador == null){
                    identificarJugador();
                } else {
                    intencion = new Intent(v.getContext(), Memoria.class);
                    intencion.putExtra("nombreJugador", nombreJugador);
                    startActivity(intencion);
                }
            }
        });

    }

    public void rellenaBaseDatos(){
        bdJuegos.obtenerDAOJuegos().InsertarJugador(new Jugador("Jugador1"));
        bdJuegos.obtenerDAOJuegos().InsertarJuego(new Juego("Flappy Bird"));
        bdJuegos.obtenerDAOJuegos().InsertarJuego(new Juego("Tres en raya"));
        bdJuegos.obtenerDAOJuegos().InsertarJuego(new Juego("Memoria"));
        bdJuegos.obtenerDAOJuegos().InsertarPartida(new Partida(1, 1, "3"));
        bdJuegos.obtenerDAOJuegos().InsertarPartida(new Partida(1, 2, "5"));
        bdJuegos.obtenerDAOJuegos().InsertarPartida(new Partida(1, 3, "20"));
    }

    public void identificarJugador(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Nombre de usuario:");
  /*      View viewInflated = LayoutInflater.from(getContext()).inflate(R.layout.text_inpu_password, (ViewGroup) getView(), false);
        final EditText input = (EditText) viewInflated.findViewById(R.id.input);
        builder.setView(viewInflated); */
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setPositiveButton("Listo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                nombreJugador = input.getText().toString();
                actualizarJuegos();
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    public void actualizarJuegos(){
        Partida partida = (Partida) bdJuegos.obtenerDAOJuegos().SacarPartidaDeJuegoPorPuntuacion(1);
        Juego juego = (Juego) bdJuegos.obtenerDAOJuegos().SacarJuego(partida.idJuego);
        Jugador jugador = (Jugador) bdJuegos.obtenerDAOJuegos().SacarJugador(partida.idJugador);
        if (nombreJugador == null) {
            titulo1.setText(juego.nombreJuego);
            jugador1.setText("Récord por \n" + jugador.nombreJugador);
            puntuacion1.setText(partida.puntuacion + " tuberías");

            partida = (Partida) bdJuegos.obtenerDAOJuegos().SacarPartidaDeJuegoPorSegundos(2);
            juego = (Juego) bdJuegos.obtenerDAOJuegos().SacarJuego(partida.idJuego);
            jugador = (Jugador) bdJuegos.obtenerDAOJuegos().SacarJugador(partida.idJugador);
            titulo2.setText(juego.nombreJuego);
            jugador2.setText("Récord por \n" + jugador.nombreJugador);
            puntuacion2.setText(partida.puntuacion + " segundos");

            partida = (Partida) bdJuegos.obtenerDAOJuegos().SacarPartidaDeJuegoPorSegundos(3);
            juego = (Juego) bdJuegos.obtenerDAOJuegos().SacarJuego(partida.idJuego);
            jugador = (Jugador) bdJuegos.obtenerDAOJuegos().SacarJugador(partida.idJugador);
            titulo3.setText(juego.nombreJuego);
            jugador3.setText("Récord por \n" + jugador.nombreJugador);
            puntuacion3.setText(partida.puntuacion + " segundos");
        } else {
            juego = (Juego) bdJuegos.obtenerDAOJuegos().SacarJuego(1);
            titulo1.setText(juego.nombreJuego);
            juego = (Juego) bdJuegos.obtenerDAOJuegos().SacarJuego(2);
            titulo2.setText(juego.nombreJuego);
            juego = (Juego) bdJuegos.obtenerDAOJuegos().SacarJuego(3);
            titulo3.setText(juego.nombreJuego);
            jugador = (Jugador) bdJuegos.obtenerDAOJuegos().SacarJugadorPorNombre(nombreJugador);
            if (jugador != null) {
                partida = (Partida) bdJuegos.obtenerDAOJuegos().SacarPartidaPorIdDeJugador(jugador.idJugador, 1);
                if (partida != null) {
                    jugador1.setText("Récord por \n" + jugador.nombreJugador);
                    puntuacion1.setText(partida.puntuacion + " tuberías");
                } else {
                    jugador1.setText(nombreJugador + " aún");
                    puntuacion1.setText("no ha jugado");
                }
                partida = (Partida) bdJuegos.obtenerDAOJuegos().SacarPartidaPorIdDeJugador(jugador.idJugador, 2);
                if (partida != null) {
                    jugador2.setText("Récord por \n" + jugador.nombreJugador);
                    puntuacion2.setText(partida.puntuacion + " segundos");
                } else {
                    jugador2.setText(nombreJugador + " aún");
                    puntuacion2.setText("no ha jugado");
                }
                partida = (Partida) bdJuegos.obtenerDAOJuegos().SacarPartidaPorIdDeJugador(jugador.idJugador, 3);
                if (partida != null) {
                    jugador3.setText("Récord por \n" + jugador.nombreJugador);
                    puntuacion3.setText(partida.puntuacion + " segundos");
                } else {
                    jugador3.setText(nombreJugador + " aún");
                    puntuacion3.setText("no ha jugado");
                }
            } else {
                jugador1.setText(nombreJugador + " aún");
                puntuacion1.setText("no ha jugado");
                jugador2.setText(nombreJugador + " aún");
                puntuacion2.setText("no ha jugado");
                jugador3.setText(nombreJugador + " aún");
                puntuacion3.setText("no ha jugado");
            }
        }
    }

    @Override
    protected void onResume() {
        actualizarJuegos();
        System.out.println(nombreJugador + "resume");
        super.onResume();
    }

}